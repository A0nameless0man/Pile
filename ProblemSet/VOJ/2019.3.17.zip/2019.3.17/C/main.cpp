#include <iostream>
#include <stdio.h>
using namespace std;
const int N=1e7+20;
bool seq[N];
char s1[N];
char s2[N];
int n;
int main()
{
  //  std::ios::sync_with_stdio(0);
    int T;
    scanf("%d", &T);
    //cin>>T;while(T--){
//    memset(seq, 0, sizeof(seq));
    //cin>>n;
    scanf("%d", &n);
    getchar();
    scanf("%s", s1);
    scanf("%s", s2);
    //bool first=true;
    for(int i=0; i<n; i++){
    seq[i]=(s1[i]==s2[i]);
      //  if(first)
    }
    int all=0;
    bool flag=false;
    for(int i=0;i<n;i++){
        if(seq[i]==0&&flag==false){
        flag=true;
        all++;
        }
        else if(flag==true&&seq[i]==1){
            flag=false;
        }
    }
    if(all==1) printf("%d\n",2*(n-1));
    else if(all==0) printf("%d\n",(n+1)*n/2);
    else if(all==2) printf("6\n");
    else printf("0\n");
        //cout<<(n- 1)*2<<endl;
    }
    return 0;
}
