#include <iostream>
#include<map>
#include<algorithm>
using namespace std;
const int INF = 100007;
map<int,int> r,l;
struct Player
{
int x,y;
bool operator<(const Player &b)const{return x<b.x;}
};
Player players[INF];
int T,n,_y;
int Max,Min,ser;
int main()
{
    cin>>T;
    while(T--)
    {
        cin>>n>>_y;
        Max=0;
        Min=INF;
        ser=0;
        r.clear();
        l.clear();
        for(int i=0;i<n;i++)
        {
            cin>>players[i].x>>players[i].y;
        }
        sort(players,players+n);
        for(int i=0;i<n;i++)
        {
            int dis = INF+players[i].x+abs(players[i].y-_y);
            if (r.count(dis)==0)
                r.insert(pair<int,int>(dis,1));
            else
                r[dis]++;
        }
        for(auto u : r)
        {
            ser+=u.second%2;
            Max=max(Max,ser);
            Min=min(Min,ser);
        }
        for(int i=0;i<n-1;i++)
        {
            int disl=INF - players[i].x+abs(players[i].y-_y);
            int disr=INF+players[i].x+abs(players[i],y-_y);
            if (l.count(disl)==0)
                l.insert(pair<int,int>(disl,1)),ser++;
            else
            {
                l[disl]++;
                if(l[disl]%2==0)
                {
                    ser--;
                }else{
                    ser++;
                }
            }
            r[disr]--;
            if (r[disr]%2==0)
                ser--;
            else
                ser++;
            Max=max(Max,ser);
            Min=min(Min,ser);
        }
        cout>>
    }
    return 0;
}
