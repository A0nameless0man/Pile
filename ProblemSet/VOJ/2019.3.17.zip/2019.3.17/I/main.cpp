#include <iostream>
#include <cstdio>
using namespace std;
typedef long long int ll;
int main()
{
    int T;
    int n,m;
    int zero;
    int a[100005];
    scanf("%d",&T);
    while(T--)
    {
        zero=0;
        scanf("%d%d",&n,&m);
        for(int i=0;i<n;i++)
        {
            scanf("%d",&a[i]);
            if(a[i]==0)
                zero++;
        }
        if(zero>m)
            printf("Impossible\n");
        else if(n==m)
            printf("Richman\n");
        else
        {
            ll ans = 0;
            int mi=1000000010;
            int mm = 0;
            m-=zero;
            for(int i=0;i<n;i++)
            {
                if(mm<m)
                {
                    if(a[i]==0)
                        continue;
                    ans+=a[i];
                    mm++;
                }
                else
                {
                    if(a[i]==0)
                        continue;
                    mi=min(mi,a[i]);
                }
            }
            ans+=(mi-1);
         //   cout<<"log"<<endl;
            printf("%lld\n",ans);
        }
    }
    return 0;
}
