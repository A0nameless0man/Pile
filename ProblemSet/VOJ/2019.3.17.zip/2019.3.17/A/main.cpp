#include <iostream>
#include<cstdio>
#include<cstring>
using namespace std;
typedef long long int ll;
int a[10]= {1,0,0,0,1,0,1,0,2,1};
int ff(ll n)
{

    int sum=0;
    if(n==0)
        return 0;
    while(n>0)
    {
        sum+=a[n%10];
        n/=10;
    }
    return sum;
}
ll f(ll n,ll k,ll m)
{
    int a;
    if(k==0)
        return n;
    a=ff(n);
    if(n==0)
    {
        if(k%2)
            return 1;
        else return 0;
    }
    if(n==1)
    {
        if(k%2)
            return 0;
        else return 1;
    }
    return f(a,k-1,m);
}
int main()
{
    ll t,k,n;
    scanf("%lld",&t);
    while(t--)
    {
        scanf("%lld%lld",&n,&k);
        printf("%lld\n",f(n,k,k));
    }
    return 0;
}
